﻿/*
 * Server Utilities Mod - Version 1.0
 * Last changed: 2013-09-09
 * Author: croxxx
 * 
 * This mod adds some useful commands to your server.
 * 
 * Following commands are added:
 * -tp_id:                  Allows the user/group to teleport to the given player ID.
 * -pull (or p):            Allows the user/group to teleport other players to their own position (identified by player name)
 * -pull_id (or p_id):      Allows the user/group to teleport other players to their own position (identified by player ID)
 *                          Usage of the pull commands can be monitored by setting "NotificationsActive" to "true".
 *                          Every user having a permission level equal to or above the one specified by "NotificationPlayerGroup" will then be notified every time the pull command is used.
 * -countdown (or count):   Allows the user/group to start a countdown (/countdown [time] [event]) Please Note: [event] only can be a single word.
 * -colors:                 Displays all colors that can be used in chat. No privilege needed.
 * -copy:                   Use "/copy start" and "/copy end" to define the area to be copied. "copypaste" privilege needed.
 * -paste:                  Use "/paste" to copy the previously defined area to your position. Use "/paste x" to crop the original area. "copypaste" privilege needed.
 * -vote:                   You can vote by typing /vote yes or /vote no. Players with privilege "startvote" can also start votings by typing /vote start [duration in min] [topic].
 * -warn:                   Allows players with "warn" privilege to warn other players for a specific reason.
 * -report:                 Allows players with "report" privilege to report other players. All users of a specified group will then be notified. If noone's currently online a message will be displayed the next time they join.
 * -afk:                    Notifies all players that the user of the afk command is AFK.
 * -btk:                    Notifies all players that the user of the btk command is no longer AFK.
 * -uptime:                 Displays the time the server has been running.
 * -me:						Sends all users the message: "[username] [message]"
 * -vanish:					Makes the user (if permitted) invisible to other players
 * -visible:				Makes the user visible again
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ManicDigger.Mods
{
	public class ServerUtilities : IMod
	{
		public void PreStart(ModManager m)
		{
			m.RequireMod("Default");
		}

		public void Start(ModManager m)
		{
			this.m = m;

			m.RegisterOnCommand(TeleportToID);
			m.RegisterCommandHelp("tp_id", "Teleports you to the player with the given ID");
			m.RegisterPrivilege("pull");
			m.RegisterOnCommand(PullPlayer);
			m.RegisterCommandHelp("pull", "Teleports the selected player to you");
			m.RegisterOnCommand(PullPlayerID);
			m.RegisterCommandHelp("pull_id", "Teleports the selected player to you (by Player ID)");
			m.RegisterPrivilege("countdown");
			m.RegisterTimer(Countdown_Tick, (double)1);
			m.RegisterOnCommand(Countdown_Start);
			m.RegisterCommandHelp("countdown", "Starts a countdown from a given number (in seconds)");
			m.RegisterOnCommand(DisplayColors);
			m.RegisterCommandHelp("colors", "Displays all colors that can be used in chat");
			m.RegisterPrivilege("copypaste");
			m.RegisterOnCommand(CopyPaste);
			m.RegisterCommandHelp("copypaste", "Allows you to copy/move specified areas of the map to other places");
			m.RegisterPrivilege("vote");
			m.RegisterPrivilege("startvote");
			m.RegisterTimer(Vote_Tick, (double)60);
			m.RegisterOnCommand(Vote);
			m.RegisterCommandHelp("startvote", "Allows you to start votings");
			m.RegisterPrivilege("warn");
			m.RegisterOnCommand(WarnPlayer);
			m.RegisterCommandHelp("warn", "Allows you to warn other players");
			m.RegisterPrivilege("report");
			m.RegisterOnCommand(ReportPlayer);
			m.RegisterOnPlayerJoin(NotifyAboutReports);
			m.RegisterCommandHelp("report", "Allows you to report other players to server staff");
			m.RegisterPrivilege("season");
			m.RegisterOnCommand(ChangeSeason);
			m.RegisterCommandHelp("season", "Allows you to change the current season");
			m.RegisterPrivilege("afk");
			m.RegisterOnCommand(SendAFK);
			m.RegisterCommandHelp("afk", "/afk [minutes] [reason]");
			m.RegisterPrivilege("btk");
			m.RegisterOnCommand(SendBTK);
			m.RegisterCommandHelp("btk", "/btk");
			m.RegisterOnCommand(DisplayUptime);
			m.RegisterTimer(Uptime_Tick, (double)1);
			m.RegisterCommandHelp("uptime", "Displays the time the server has been running");
			m.RegisterPrivilege("me");
			m.RegisterOnCommand(SendMe);
			m.RegisterCommandHelp("me", "/me [message]");
			m.RegisterPrivilege("vanish");
			m.RegisterOnCommand(SetSpectate);
			m.RegisterCommandHelp("vanish", "/vanish - Poof! You're gone.");

			System.Console.WriteLine("Loaded ServerUtilities Version 1.0");
			m.LogServerEvent("Loaded ServerUtilities Version 1.0");
		}
		//Enter the desired language code here. Currently supported are EN and DE.
		string languageCode = "EN";
		//Enable or disable all notifications about usage of "pull" command.
		bool NotificationActive = true;
		//Thepermission level of the player group which shall be notified. (includes all groups above)
		int NotificationPlayerGroup = 3;	//Default: 3 - Admin rank (in standard configuration)
		//Enable global warnings (Sends all players the message: Player X has been warned by Y for Z)
		bool GlobalWarnings = true;
		//Notify every user having this (or a higher) permission level when a user is reported
		int ReportToGroup = 3;	//Default: 3 - Admin rank (in standard configuration)

		//Internal variables.
		//DO NOT CHANGE!
		ModManager m;
		int UptimeSeconds = 0, UptimeMinutes = 0, UptimeHours = 0, UptimeDays = 0;

		struct Vector3i
		{
			public Vector3i(int x, int y, int z)
			{
				this.x = x;
				this.y = y;
				this.z = z;
			}
			public int x;
			public int y;
			public int z;
		}
		struct Area
		{
			public Area(Vector3i startpos, Vector3i endpos)
			{
				if (startpos.x < endpos.x)
				{
					start.x = startpos.x;
					end.x = endpos.x;
				}
				else
				{
					start.x = endpos.x;
					end.x = startpos.x;
				}
				if (startpos.y < endpos.y)
				{
					start.y = startpos.y;
					end.y = endpos.y;
				}
				else
				{
					start.y = endpos.y;
					end.y = startpos.y;
				}
				if (startpos.z < endpos.z)
				{
					start.z = startpos.z;
					end.z = endpos.z;
				}
				else
				{
					start.z = endpos.z;
					end.z = startpos.z;
				}
				size.x = (end.x - start.x) + 1;
				size.y = (end.y - start.y) + 1;
				size.z = (end.z - start.z) + 1;
			}
			public Vector3i start;
			public Vector3i end;
			public readonly Vector3i size;
		}

		string GetLocalizedString(int StringID)
		{
			switch (languageCode)
			{
					#region German translation
				case "DE":
					switch (StringID)
					{
						case 0:
							return "Du darfst dich nicht teleportieren.";
						case 1:
							return "Argument ist keine Zahl.";
						case 2:
							return "Die Zahl ist zu groß für einen Int32.";
						case 3:
							return "&7Teleport erfolgreich.";
						case 4:
							return "Spieler ID {0} existiert nicht.";
						case 5:
							return "Du darfst andere Spieler nicht zu dir teleportieren.";
						case 6:
							return "&7Dein Meister {0} hat dich zu sich teleportiert.";
						case 7:
							return "&6INFO: &7{0} hat {1} zu sich teleportiert.";
						case 8:
							return "Dein Ziel hat einen höheren Rang als du.";
						case 9:
							return "Der Spieler {0} existiert nicht.";
						case 10:
							return "Noch &6{0} &fStunden bis{1}";
						case 11:
							return "Noch &6{0} &fStunde bis{1}";
						case 12:
							return "Noch &6{0} &fMinuten bis{1}";
						case 13:
							return "Noch &6{0} &fMinute bis{1}";
						case 14:
							return "Noch &6{0} &fSekunden bis{1}";
						case 15:
							return "Noch &6{0} &fSekunde bis{1}";
						case 16:
							return "Du darfst keinen Countdown starten.";
						case 17:
							return "Ungültige Argumente. Gib /help für Hilfe ein.";
						case 18:
							return "&7Countdown erfolgreich gesetzt.";
						case 19:
							return "Nur ein Countdown kann aktiv sein.";
						case 20:
							return "Du darfst nicht Kopieren/Einfügen.";
						case 21:
							return "&7Anfang des Kopier-Bereichs auf {0}, {1}, {2} gesetzt.";
						case 22:
							return "&7Ende des Kopier-Bereichs auf {0}, {1}, {2} gesetzt.";
						case 23:
							return "Ungültiges Argument. Erlaubt sind start und end.";
						case 24:
							return "&7Aktuelle Abstimmung:{0}";
						case 25:
							return "{0} Minuten verbleiben.";
						case 26:
							return "{0} Minute verbleibt.";
						case 27:
							return "&7Abstimmung abgeschlossen.";
						case 28:
							return "&7Frage:{0}";
						case 29:
							return "&7Gestartet von: {0}";
						case 30:
							return "&7Statistik:";
						case 31:
							return "{0} Stimmen &2DAFÜR&f.";
						case 32:
							return "{0} Stimmen &4DAGEGEN&f.";
						case 33:
							return "&2Abstimmung erfolgreich!";
						case 34:
							return "&6Gleichstand...";
						case 35:
							return "&4Abstimmung fehlgeschlagen!";
						case 36:
							return "&7Ergebnis: {0}";
						case 37:
							return "Du hast kein Stimmrecht.";
						case 38:
							return "Es läuft derzeit keine Abstimmung.";
						case 39:
							return "Du hast bereits eine Stimme abgegeben!";
						case 40:
							return "&2Vielen Dank, deine Stimme wurde gezählt.";
						case 41:
							return "&6ABSTIMMUNGEN";
						case 42:
							return "--------------------------------------------------";
						case 43:
							return "Wenn eine Abstimmung läuft, kannst du:";
						case 44:
							return "-&6/vote yes &feingeben, um &2DAFÜR &fzu stimmen.";
						case 45:
							return "-&6/vote no &feingeben, um &4DAGEGEN &fzu stimmen.";
						case 46:
							return "-&6/vote info &feingeben, um den aktuellen Stand zu sehen.";
						case 47:
							return "Du darfst keine Abstimmungen starten.";
						case 48:
							return "Es läuft bereits eine Abstimmung.";
						case 49:
							return "&7Bitte warte kurz, bis der Server die Abstimmung bekannt gibt.";
						case 50:
							return "&6INFO: &7Das kann bis zu einer Minute dauern.";
						case 51:
							return "&7Du kannst die Abstimmung durch &6/vote cancel &7abbrechen.";
						case 52:
							return "Du darfst keine Abstimmungen abbrechen.";
						case 53:
							return "&7Die aktuelle Abstimung wurde von {0} abgebrochen.";
						case 54:
							return "Du darfst andere Spieler nicht verwarnen.";
						case 55:
							return "&7{0} &fwurde von &7{1} &4gewarnt&f. Grund:&7{2}";
						case 56:
							return "{0}, du wurdest von {1} &4gewarnt&f. Grund:{2}";
						case 57:
							return "Du darfst andere Spieler nicht melden.";
						case 58:
							return "{0} hat {1} &4gemeldet&f. Grund:{2}";
						case 59:
							return "Du hast {0} erfolgreich gemeldet. Grund:{1}";
						case 60:
							return "Du darfst die aktuelle Jahreszeit nicht verändern.";
						case 61:
							return "Jahreszeit ID {0} ist ungültig.";
						case 62:
							return "Start und Ende des Kopierbereichs nicht von derselben Person festgelegt.";
						case 63:
							return "Start oder Ende des Kopierbereichs nicht von DIR festgelegt.";
						case 64:
							return "Du darfst anderen nicht sagen, dass du AFK bist.";
						case 65:
							return "&7{0} ist für {1} Minuten AFK. Grund:{2}";
						case 66:
							return "&7{0} Tage, {1} Stunden, {2} Minuten, {3} Sekunden.";
						case 67:
							return "&7{0} ist wieder da.";
						case 68:
							return "Du darfst /me nich verwenden.";
						case 69:
							return "Du darfst dich nicht unsichtbar machen.";
						case 70:
							return "&7{0} ist verschwunden.";
						case 71:
							return "&7{0} ist wieder aufgetaucht.";

						default:
							return string.Format("&4FEHLER: &fString ID {0} existiert nicht.", StringID.ToString());
					}
					#endregion

					#region English translation
				case "EN":
					switch (StringID)
					{
						case 0:
							return "You are not allowed to teleport yourself.";
						case 1:
							return "Argument is not a number.";
						case 2:
							return "The number is too big for an Int32.";
						case 3:
							return "&7Teleport successful.";
						case 4:
							return "Player ID {0} does not exist.";
						case 5:
							return "You are not allowed to pull other players.";
						case 6:
							return "&7Your master {0} pulled you to his position.";
						case 7:
							return "&6INFO: &7{0} pulled {1} to his position.";
						case 8:
							return "Your target has a higher permission level than you.";
						case 9:
							return "Player {0} does not exist.";
						case 10:
							return "&6{0} &fhours left until{1}";
						case 11:
							return "&6{0} &fhour left until{1}";
						case 12:
							return "&6{0} &fminutes left until{1}";
						case 13:
							return "&6{0} &fminute left until{1}";
						case 14:
							return "&6{0} &fseconds left until{1}";
						case 15:
							return "&6{0} &fsecond left until{1}";
						case 16:
							return "You are not allowed to start a countdown.";
						case 17:
							return "Invalid arguments. Type /help to see command's usage.";
						case 18:
							return "&7Countdown successfully set.";
						case 19:
							return "Only one countdown can be active at a time.";
						case 20:
							return "You are not allowed to use copy/paste.";
						case 21:
							return "Successfully set Copy Area Start to {0}, {1}, {2}.";
						case 22:
							return "Successfully set Copy Area End to {0}, {1}, {2}.";
						case 23:
							return "Invalid argument. Use 'start' and 'end' to define an area.";
						case 24:
							return "&7Current voting:{0}";
						case 25:
							return "{0} minutes left.";
						case 26:
							return "{0} minute left.";
						case 27:
							return "&7Voting closed.";
						case 28:
							return "&7Topic:{0}";
						case 29:
							return "&7Started by: {0}";
						case 30:
							return "&7Statistics:";
						case 31:
							return "{0} votes &2FOR &fthe subject.";
						case 32:
							return "{0} votes &4AGAINST &fthe subject.";
						case 33:
							return "&2Vote passed!";
						case 34:
							return "&6Votes are even!";
						case 35:
							return "&4Vote failed!";
						case 36:
							return "&7Result: {0}";
						case 37:
							return "You are not allowed to vote.";
						case 38:
							return "There's currently no vote in progress.";
						case 39:
							return "You have already voted!";
						case 40:
							return "&2Thank You, your vote has been counted.";
						case 41:
							return "VOTING";
						case 42:
							return "--------------------------------------------------";
						case 43:
							return "Once a player has started a vote you can:";
						case 44:
							return "-type &6/vote yes &fto vote &2FOR &fthe topic.";
						case 45:
							return "-type &6/vote no &fto vote &4AGAINST &fthe topic.";
						case 46:
							return "-type &6/vote info &fto view the current statistics.";
						case 47:
							return "You are not allowed to start votings.";
						case 48:
							return "There is already a vote in progress.";
						case 49:
							return "&7Please wait a few moments until the server announces your voting.";
						case 50:
							return "&6INFO: &7This can take up to 1 minute.";
						case 51:
							return "&7You can cancel this voting by typing &6/vote cancel &7in chat.";
						case 52:
							return "You are not allowed to cancel votings.";
						case 53:
							return "&7Current voting was cancelled by {0}.";
						case 54:
							return "You are not allowed to warn other players!";
						case 55:
							return "&7{0} &fhas been &4warned &fby &7{1}. &fReason:&7{2}";
						case 56:
							return "{0}, you have been &4warned &fby {1}. Reason:{2}";
						case 57:
							return "You are not allowed to report other players.";
						case 58:
							return "{0} &4reported &f{1}. Reason:{2}";
						case 59:
							return "You have successfully reported {0}. Reason:{1}";
						case 60:
							return "You are not allowed to change the current season!";
						case 61:
							return "Season ID {0} is not a valid season.";
						case 62:
							return "Copy Start and End not set by same person.";
						case 63:
							return "Copy Start or End not set by YOU.";
						case 64:
							return "You are not allowed to notify others that you're AFK.";
						case 65:
							return "&7{0} will be AFK for {1} minutes. Reason:{2}";
						case 66:
							return "&7{0} Days, {1} Hours, {2} Minutes, {3} Seconds.";
						case 67:
							return "&7{0} is back.";
						case 68:
							return "You are not allowed to use /me.";
						case 69:
							return "You are not allowed to vanish.";
						case 70:
							return "&7{0} vanished. Poof!";
						case 71:
							return "&7{0} reappeared.";

						default:
							return string.Format("&4ERROR: &fString ID {0} does not exist.", StringID.ToString());
					}
					#endregion

				default:
					System.Console.WriteLine(string.Format("ERROR: Language code {0} not found!", languageCode));
					return string.Format("&4ERROR: &fThe language code {0} is not in the list.", languageCode);
			}
		}
		
		Vector3i GetPlayerPosition(int PlayerID)
		{
			return new Vector3i((int)m.GetPlayerPositionX(PlayerID), (int)m.GetPlayerPositionY(PlayerID), (int)m.GetPlayerPositionZ(PlayerID));
		}
		
		void NotifyAboutActivity(string action)
		{
			if (NotificationActive)
			{
				int[] playerlist = m.AllPlayers();
				for (int i = 0; i < playerlist.Length; i++)
				{
					if (m.GetPlayerPermissionLevel(playerlist[i]) >= NotificationPlayerGroup)
					{
						m.SendMessage(playerlist[i], action);
					}
				}
			}
			System.Console.WriteLine(string.Format("INFO:  {0}", action));
		}

		bool TeleportToID(int player, string command, string argument)
		{
			if (command.Equals("tp_id", StringComparison.InvariantCultureIgnoreCase))
			{
				if (!m.PlayerHasPrivilege(player, "tp"))
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(0));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to teleport by ID (no permission)", m.GetPlayerName(player)));
					return true;
				}
				int targetID;
				try
				{
					targetID = Convert.ToInt32(argument);
				}
				catch (FormatException)
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(1));
					return true;
				}
				catch (OverflowException)
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(2));
					return true;
				}
				//Check if playerID exists
				int[] playerlist = m.AllPlayers();
				bool ID_in_Playerlist = false;
				for (int i = 0; i < playerlist.Length; i++)
				{
					if (playerlist[i] == targetID)
					{
						ID_in_Playerlist = true;
						break;
					}
				}
				if (ID_in_Playerlist)
				{
					//Do the teleport magic
					m.SetPlayerPosition(player, m.GetPlayerPositionX(targetID), m.GetPlayerPositionY(targetID), m.GetPlayerPositionZ(targetID));
					m.SendMessage(player, GetLocalizedString(3));
					return true;
				}
				else
				{
					m.SendMessage(player, m.colorError() + string.Format(GetLocalizedString(4), targetID.ToString()));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to teleport by ID (target does not exist)", m.GetPlayerName(player)));
					return true;
				}
			}
			return false;
		}

		bool PullPlayer(int player, string command, string argument)
		{
			if ((command.Equals("pull", StringComparison.InvariantCultureIgnoreCase)) || (command.Equals("p", StringComparison.InvariantCultureIgnoreCase)))
			{
				if (!m.PlayerHasPrivilege(player, "pull"))
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(5));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to pull someone (no permission)", m.GetPlayerName(player)));
					return true;
				}
				int target = -1;
				int[] allPlayers = m.AllPlayers();
				for (int i = 0; i < allPlayers.Length; i++)
				{
					if (argument.Equals(m.GetPlayerName(allPlayers[i]), StringComparison.InvariantCultureIgnoreCase))
					{
						target = allPlayers[i];
						break;
					}
				}
				if (target != -1)
				{
					if (m.GetPlayerPermissionLevel(player) >= m.GetPlayerPermissionLevel(target))
					{
						//Do the teleport magic
						m.SetPlayerPosition(target, m.GetPlayerPositionX(player), m.GetPlayerPositionY(player), m.GetPlayerPositionZ(player));
						m.SendMessage(player, GetLocalizedString(3));
						m.SendMessage(target, string.Format(GetLocalizedString(6), m.GetPlayerName(player)));
						//Notify the defined group (abuse prevention)
						NotifyAboutActivity(string.Format(GetLocalizedString(7), m.GetPlayerName(player), m.GetPlayerName(target)));
						return true;
					}
					m.SendMessage(player, GetLocalizedString(8));
					return true;
				}
				else
				{
					m.SendMessage(player, m.colorError() + string.Format(GetLocalizedString(9), argument));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to pull someone (target does not exist)", m.GetPlayerName(player)));
					return true;
				}
			}
			return false;
		}

		bool PullPlayerID(int player, string command, string argument)
		{
			if ((command.Equals("pull_id", StringComparison.InvariantCultureIgnoreCase)) || (command.Equals("p_id", StringComparison.InvariantCultureIgnoreCase)))
			{
				if (!m.PlayerHasPrivilege(player, "pull"))
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(5));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to pull someone by ID (no permission)", m.GetPlayerName(player)));
					return true;
				}
				int targetID;
				try
				{
					targetID = Convert.ToInt32(argument);
				}
				catch (FormatException)
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(1));
					return true;
				}
				catch (OverflowException)
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(2));
					return true;
				}
				//Check if playerID exists
				int[] playerlist = m.AllPlayers();
				bool ID_in_Playerlist = false;
				for (int i = 0; i < playerlist.Length; i++)
				{
					if (playerlist[i] == targetID)
					{
						ID_in_Playerlist = true;
						break;
					}
				}
				if (ID_in_Playerlist)
				{
					if (m.GetPlayerPermissionLevel(player) >= m.GetPlayerPermissionLevel(targetID))
					{
						//Do the teleport magic
						m.SetPlayerPosition(targetID, m.GetPlayerPositionX(player), m.GetPlayerPositionY(player), m.GetPlayerPositionZ(player));
						m.SendMessage(player, GetLocalizedString(3));
						m.SendMessage(targetID, string.Format(GetLocalizedString(6), m.GetPlayerName(player)));
						//Notify the defined group (abuse prevention)
						NotifyAboutActivity(string.Format(GetLocalizedString(7), m.GetPlayerName(player), m.GetPlayerName(targetID)));
						return true;
					}
					m.SendMessage(player, GetLocalizedString(8));
					return true;
				}
				else
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(9));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to pull someone by ID (target does not exist)", m.GetPlayerName(player)));
					return true;
				}
			}
			return false;
		}

		bool CountdownIsActive = false;
		int CountdownCurrent = -1;
		string CountdownReason = "";
		
		void Countdown_Tick()
		{
			if (CountdownIsActive)
			{
				if (CountdownCurrent > 3600)
				{
					if ((CountdownCurrent % 3600) == 0)
					{
						if ((CountdownCurrent / 3600) == 1)
							m.SendMessageToAll(string.Format(GetLocalizedString(11), (int)(CountdownCurrent / 60), CountdownReason));
						else
							m.SendMessageToAll(string.Format(GetLocalizedString(10), (int)(CountdownCurrent / 60), CountdownReason));
						CountdownCurrent--;
						return;
					}
					CountdownCurrent--;
					return;
				}
				else if (CountdownCurrent > 60)
				{
					if ((CountdownCurrent % 60) == 0)
					{
						if ((CountdownCurrent / 60) == 1)
							m.SendMessageToAll(string.Format(GetLocalizedString(13), (int)(CountdownCurrent / 60), CountdownReason));
						else
							m.SendMessageToAll(string.Format(GetLocalizedString(12), (int)(CountdownCurrent / 60), CountdownReason));
						CountdownCurrent--;
						return;
					}
					CountdownCurrent--;
					return;
				}
				else if (CountdownCurrent > 10)
				{
					if ((CountdownCurrent % 10) == 0)
					{
						m.SendMessageToAll(string.Format(GetLocalizedString(14), (int)(CountdownCurrent), CountdownReason));
						CountdownCurrent--;
						return;
					}
					CountdownCurrent--;
					return;
				}
				else if (CountdownCurrent > 0)
				{
					if (CountdownCurrent == 1)
						m.SendMessageToAll(string.Format(GetLocalizedString(15), (int)(CountdownCurrent), CountdownReason));
					else
						m.SendMessageToAll(string.Format(GetLocalizedString(14), (int)(CountdownCurrent), CountdownReason));
					CountdownCurrent--;
					return;
				}
				else
				{
					m.SendMessageToAll(" ");
					m.SendMessageToAll(string.Format("{0}", CountdownReason));
					CountdownIsActive = false;
					CountdownCurrent = -1;
					CountdownReason = "";
				}
			}
		}
		
		bool Countdown_Start(int player, string command, string argument)
		{
			if ((command.Equals("countdown", StringComparison.InvariantCultureIgnoreCase)) || (command.Equals("count", StringComparison.InvariantCultureIgnoreCase)))
			{
				if (!m.PlayerHasPrivilege(player, "countdown"))
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(16));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to start a countdown (no permission)", m.GetPlayerName(player)));
					return true;
				}
				if (argument.Equals("abort", StringComparison.InvariantCultureIgnoreCase))
				{
					if (CountdownIsActive)
					{
						CountdownIsActive = false;
						CountdownCurrent = -1;
						CountdownReason = "";
						m.SendMessageToAll(string.Format("&7{0} aborted the current countdown.", m.GetPlayerName(player)));
					}
					else
					{
						m.SendMessage(player, "&7There is no countdown running currently.");
						System.Console.WriteLine(string.Format("INFO:  {0} tried to abort the current countdown (no countdown active)", m.GetPlayerName(player)));
					}
					return true;
				}
				if (!CountdownIsActive)
				{
					string givenReason = "";
					int givenTime;
					try
					{
						string[] args = argument.Split(' ');
						givenTime = int.Parse(args[0]);
						for (int i = 1; i < args.Length; i++)
						{
							givenReason = givenReason + " " + args[i];
						}
					}
					catch
					{
						m.SendMessage(player, m.colorError() + GetLocalizedString(17));
						return true;
					}
					if (string.IsNullOrEmpty(givenReason))
					{
						//Invalid (or missing) argument(s)
						m.SendMessage(player, m.colorError() + GetLocalizedString(17));
						return true;
					}
					CountdownCurrent = givenTime;
					CountdownReason = givenReason;
					CountdownIsActive = true;

					System.Console.WriteLine(string.Format("INFO:  {0} started a countdown.", m.GetPlayerName(player)));
					m.SendMessage(player, GetLocalizedString(18));
					return true;
				}
				else
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(19));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to start a countdown (countdown already running)", m.GetPlayerName(player)));
					return true;
				}
			}
			return false;
		}

		bool DisplayColors(int player, string command, string argument)
		{
			if (command.Equals("colors", StringComparison.InvariantCultureIgnoreCase))
			{
				m.SendMessage(player, "&00 &11 &22 &33 &44 &55 &66 &77 &88 &99 &aa &bb &cc &dd &ee &ff");
				return true;
			}
			return false;
		}

		Vector3i copy_start;
		Vector3i copy_end;
		Vector3i copy_paste;
		string start_set_by = "";
		string end_set_by = "";
		
		bool CopyPaste(int player, string command, string argument)
		{
			bool copy_deleteSource = false;

			if (command.Equals("copy", StringComparison.InvariantCultureIgnoreCase))
			{
				if (!m.PlayerHasPrivilege(player, "copypaste"))
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(20));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to use copy (no permission)", m.GetPlayerName(player)));
					return true;
				}
				if (argument.Equals("start", StringComparison.InvariantCultureIgnoreCase))
				{
					copy_start = GetPlayerPosition(player);
					m.SendMessage(player, string.Format(GetLocalizedString(21), copy_start.x, copy_start.y, copy_start.z));
					m.SendMessageToAll(string.Format("&7{0}: Copy Start", m.GetPlayerName(player)));
					start_set_by = m.GetPlayerName(player);
					return true;
				}
				if (argument.Equals("end", StringComparison.InvariantCultureIgnoreCase))
				{
					copy_end = GetPlayerPosition(player);
					m.SendMessage(player, string.Format(GetLocalizedString(22), copy_end.x, copy_end.y, copy_end.z));
					m.SendMessageToAll(string.Format("&7{0}: Copy End", m.GetPlayerName(player)));
					end_set_by = m.GetPlayerName(player);
					return true;
				}
				m.SendMessage(player, m.colorError() + GetLocalizedString(23));
				return true;
			}
			if (command.Equals("paste", StringComparison.InvariantCultureIgnoreCase))
			{
				if (!m.PlayerHasPrivilege(player, "copypaste"))
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(20));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to use paste (no permission)", m.GetPlayerName(player)));
					return true;
				}
				if (argument.Equals("x", StringComparison.InvariantCultureIgnoreCase))
				{
					copy_deleteSource = true;
					System.Console.WriteLine(string.Format("INFO:  {0} set crop mode option.", m.GetPlayerName(player)));
				}

				if (!start_set_by.Equals(end_set_by, StringComparison.InvariantCultureIgnoreCase))
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(62));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to use paste (start/end not set by same player)", m.GetPlayerName(player)));
					return true;
				}
				if ((!start_set_by.Equals(m.GetPlayerName(player), StringComparison.InvariantCultureIgnoreCase)) || (!end_set_by.Equals(m.GetPlayerName(player), StringComparison.InvariantCultureIgnoreCase)))
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(63));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to teleport (start/end not set by this player)", m.GetPlayerName(player)));
					return true;
				}

				System.Console.WriteLine(string.Format("INFO:  {0} started copy process.", m.GetPlayerName(player)));
				m.SendMessageToAll("&7Copy process started. Lag is likely.");

				Vector3i start, end;
				copy_paste = GetPlayerPosition(player);

				if (copy_start.x < copy_end.x)
				{
					start.x = copy_start.x;
					end.x = copy_end.x;
				}
				else
				{
					start.x = copy_end.x;
					end.x = copy_start.x;
				}
				if (copy_start.y < copy_end.y)
				{
					start.y = copy_start.y;
					end.y = copy_end.y;
				}
				else
				{
					start.y = copy_end.y;
					end.y = copy_start.y;
				}
				if (copy_start.z < copy_end.z)
				{
					start.z = copy_start.z;
					end.z = copy_end.z;
				}
				else
				{
					start.z = copy_end.z;
					end.z = copy_start.z;
				}

				if (copy_deleteSource)
				{
					for (int x = start.x; x <= end.x; x++)
					{
						for (int y = start.y; y <= end.y; y++)
						{
							for (int z = start.z; z <= end.z; z++)
							{
								m.SetBlock(copy_paste.x + (x - start.x), copy_paste.y + (y - start.y), copy_paste.z + (z - start.z), m.GetBlock(x, y, z));
								//If crop mode is active set source blocks to "Empty"
								m.SetBlock(x, y, z, 0);
							}
						}
					}
				}
				else
				{
					for (int x = start.x; x <= end.x; x++)
					{
						for (int y = start.y; y <= end.y; y++)
						{
							for (int z = start.z; z <= end.z; z++)
							{
								m.SetBlock(copy_paste.x + (x - start.x), copy_paste.y + (y - start.y), copy_paste.z + (z - start.z), m.GetBlock(x, y, z));
							}
						}
					}
				}
				System.Console.WriteLine("INFO:  Copying finished");
				m.SendMessageToAll("&7Copy process finished.");
				return true;
			}
			return false;
		}

		bool VoteInProgress = false;
		int VoteTime, VoteFor, VoteAgainst = 0;
		string VoteSubject, VoteStartedBy, VoteResult = "";
		List<string> voters = new List<string>();

		void Vote_Tick()
		{
			if (VoteInProgress)
			{
				if (VoteTime > 0)
				{
					m.SendMessageToAll(string.Format(GetLocalizedString(24), VoteSubject));
					if (VoteTime == 1)
					{
						m.SendMessageToAll(string.Format(GetLocalizedString(26), VoteTime.ToString()));
					}
					else
					{
						m.SendMessageToAll(string.Format(GetLocalizedString(25), VoteTime.ToString()));
					}
					VoteTime--;
				}
				else
				{
					m.SendMessageToAll(GetLocalizedString(27));
					m.SendMessageToAll(string.Format(GetLocalizedString(28), VoteSubject));
					m.SendMessageToAll(string.Format(GetLocalizedString(29), VoteStartedBy));
					m.SendMessageToAll(" ");
					m.SendMessageToAll(GetLocalizedString(30));
					m.SendMessageToAll(string.Format(GetLocalizedString(31), VoteFor.ToString()));
					m.SendMessageToAll(string.Format(GetLocalizedString(32), VoteAgainst.ToString()));
					if (VoteFor > VoteAgainst)
					{
						VoteResult = GetLocalizedString(33);
					}
					else if (VoteFor == VoteAgainst)
					{
						VoteResult = GetLocalizedString(34);
					}
					else
					{
						VoteResult = GetLocalizedString(35);
					}
					m.SendMessageToAll(" ");
					m.SendMessageToAll(string.Format(GetLocalizedString(36), VoteResult));
					VoteSubject = "";
					VoteStartedBy = "";
					VoteResult = "";
					VoteFor = 0;
					VoteAgainst = 0;
					voters.Clear(); //Reset list of people who have voted
					VoteInProgress = false;
				}
			}
		}
		
		bool Vote(int player, string command, string argument)
		{
			string[] args;
			string option = "";
			try
			{
				args = argument.Split(' ');
				option = args[0];
			}
			catch
			{
				m.SendMessage(player, m.colorError() + GetLocalizedString(17));
				return true;
			}
			
			if (command.Equals("vote", StringComparison.InvariantCultureIgnoreCase))
			{
				if (option.Equals("yes", StringComparison.InvariantCultureIgnoreCase))
				{
					if (!m.PlayerHasPrivilege(player, "vote"))
					{
						m.SendMessage(player, m.colorError() + GetLocalizedString(37));
						System.Console.WriteLine(string.Format("INFO:  {0} tried to vote (no permission)", m.GetPlayerName(player)));
						return true;
					}
					if (!VoteInProgress)
					{
						m.SendMessage(player, m.colorError() + GetLocalizedString(38));
						return true;
					}
					foreach (string current in voters)
					{
						if (current.Equals(m.GetPlayerName(player), StringComparison.InvariantCultureIgnoreCase))
						{
							m.SendMessage(player, m.colorError() + GetLocalizedString(39));
							return true;
						}
					}
					VoteFor++;
					voters.Add(m.GetPlayerName(player));
					m.SendMessage(player, GetLocalizedString(40));
					return true;
				}
				if (option.Equals("no", StringComparison.InvariantCultureIgnoreCase))
				{
					if (!m.PlayerHasPrivilege(player, "vote"))
					{
						m.SendMessage(player, m.colorError() + GetLocalizedString(37));
						System.Console.WriteLine(string.Format("INFO:  {0} tried to vote (no permission)", m.GetPlayerName(player)));
						return true;
					}
					if (!VoteInProgress)
					{
						m.SendMessage(player, m.colorError() + GetLocalizedString(38));
						return true;
					}
					foreach (string current in voters)
					{
						if (current.Equals(m.GetPlayerName(player), StringComparison.InvariantCultureIgnoreCase))
						{
							m.SendMessage(player, m.colorError() + GetLocalizedString(39));
							return true;
						}
					}
					VoteAgainst++;
					voters.Add(m.GetPlayerName(player));
					m.SendMessage(player, GetLocalizedString(40));
					return true;
				}
				if (option.Equals("help", StringComparison.InvariantCultureIgnoreCase))
				{
					m.SendMessage(player, GetLocalizedString(41));
					m.SendMessage(player, GetLocalizedString(42));
					m.SendMessage(player, GetLocalizedString(43));
					m.SendMessage(player, GetLocalizedString(44));
					m.SendMessage(player, GetLocalizedString(45));
					m.SendMessage(player, GetLocalizedString(46));
					return true;
				}
				if (option.Equals("info", StringComparison.InvariantCultureIgnoreCase))
				{
					if (!VoteInProgress)
					{
						m.SendMessage(player, m.colorError() + GetLocalizedString(38));
						return true;
					}
					m.SendMessage(player, string.Format(GetLocalizedString(28), VoteSubject));
					m.SendMessage(player, string.Format(GetLocalizedString(29), VoteStartedBy));
					m.SendMessage(player, " ");
					m.SendMessage(player, GetLocalizedString(30));
					m.SendMessage(player, string.Format(GetLocalizedString(31), VoteFor.ToString()));
					m.SendMessage(player, string.Format(GetLocalizedString(32), VoteAgainst.ToString()));
					return true;
				}
				if (option.Equals("start", StringComparison.InvariantCultureIgnoreCase))
				{
					if (!m.PlayerHasPrivilege(player, "startvote"))
					{
						m.SendMessage(player, m.colorError() + GetLocalizedString(47));
						System.Console.WriteLine(string.Format("INFO:  {0} tried to start a vote (no permission)", m.GetPlayerName(player)));
						return true;
					}
					if (VoteInProgress)
					{
						m.SendMessage(player, m.colorError() + GetLocalizedString(48));
						System.Console.WriteLine(string.Format("INFO:  {0} tried to start a vote (there is already a vote)", m.GetPlayerName(player)));
						return true;
					}
					try
					{
						VoteTime = int.Parse(args[1]);
						for (int i = 2; i < args.Length; i++)
						{
							VoteSubject = VoteSubject + " " + args[i];
						}
					}
					catch
					{
						m.SendMessage(player, m.colorError() + GetLocalizedString(17));
						return true;
					}
					VoteInProgress = true;
					VoteStartedBy = m.GetPlayerName(player);
					m.SendMessage(player, GetLocalizedString(49));
					m.SendMessage(player, GetLocalizedString(50));
					m.SendMessage(player, GetLocalizedString(51));
					return true;
				}
				if (option.Equals("cancel", StringComparison.InvariantCultureIgnoreCase))
				{
					if (!m.PlayerHasPrivilege(player, "startvote"))
					{
						m.SendMessage(player, m.colorError() + GetLocalizedString(52));
						return true;
					}
					if (!VoteInProgress)
					{
						m.SendMessage(player, m.colorError() + GetLocalizedString(38));
						return true;
					}
					VoteInProgress = false;
					VoteSubject = "";
					VoteStartedBy = "";
					VoteResult = "";
					VoteFor = 0;
					VoteAgainst = 0;
					VoteTime = 0;
					voters.Clear(); //Reset list of people who have voted
					m.SendMessageToAll(string.Format(GetLocalizedString(53), m.GetPlayerName(player)));
					return true;
				}
				m.SendMessage(player, m.colorError() + GetLocalizedString(17));
				return true;
			}
			return false;
		}

		bool WarnPlayer(int player, string command, string argument)
		{
			if (command.Equals("warn", StringComparison.InvariantCultureIgnoreCase))
			{
				if (!m.PlayerHasPrivilege(player, "warn"))
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(54));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to warn someone (no permission)", m.GetPlayerName(player)));
					return true;
				}
				string[] args;
				string warnplayer = "";
				string givenReason = "";
				try
				{
					args = argument.Split(' ');
					warnplayer = args[0];
					for (int i = 1; i < args.Length; i++)
					{
						givenReason = givenReason + " " + args[i];
					}
				}
				catch
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(17));
					return true;
				}
				if (string.IsNullOrEmpty(warnplayer) || string.IsNullOrEmpty(givenReason))
				{
					//Invalid (or missing) argument(s)
					m.SendMessage(player, m.colorError() + GetLocalizedString(17));
					return true;
				}

				//Check if the specified player exists (is currently online)
				bool playerExists = false;
				int[] allPlayers = m.AllPlayers();
				for (int i = 0; i < allPlayers.Length; i++)
				{
					if (warnplayer.Equals(m.GetPlayerName(allPlayers[i]), StringComparison.InvariantCultureIgnoreCase))
					{
						playerExists = true;
						break;
					}
				}
				if (!playerExists)
				{
					m.SendMessage(player, m.colorError() + string.Format(GetLocalizedString(9), warnplayer));
					return true;
				}

				System.Console.WriteLine(string.Format("INFO:  {0} warned {1}.", m.GetPlayerName(player), warnplayer));

				if (GlobalWarnings)
				{
					m.SendMessageToAll(string.Format(GetLocalizedString(55), warnplayer, m.GetPlayerName(player), givenReason));
					return true;
				}
				else
				{
					m.SendMessage(player, string.Format(GetLocalizedString(56), warnplayer, m.GetPlayerName(player), givenReason));
					return true;
				}
			}
			return false;
		}

		List<string[]> reportedPlayers = new List<string[]>();
		
		bool ReportPlayer(int player, string command, string argument)
		{
			if (command.Equals("report", StringComparison.InvariantCultureIgnoreCase))
			{
				if (!m.PlayerHasPrivilege(player, "report"))
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(57));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to report someone (no permission)", m.GetPlayerName(player)));
					return true;
				}
				string[] args;
				string rep_player = "";
				string givenReason = "";
				try
				{
					args = argument.Split(' ');
					rep_player = args[0];
					for (int i = 1; i < args.Length; i++)
					{
						givenReason = givenReason + " " + args[i];
					}
				}
				catch
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(17));
					return true;
				}
				if (string.IsNullOrEmpty(rep_player) || string.IsNullOrEmpty(givenReason))
				{
					//Invalid (or missing) argument(s)
					m.SendMessage(player, m.colorError() + GetLocalizedString(17));
					return true;
				}

				//Check if the specified player exists (is currently online)
				bool playerExists = false;
				int[] allPlayers = m.AllPlayers();
				for (int i = 0; i < allPlayers.Length; i++)
				{
					if (rep_player.Equals(m.GetPlayerName(allPlayers[i]), StringComparison.InvariantCultureIgnoreCase))
					{
						playerExists = true;
						break;
					}
				}
				if (!playerExists)
				{
					m.SendMessage(player, m.colorError() + string.Format(GetLocalizedString(9), rep_player));
					return true;
				}

				//Check if at least one member of any group with a permission level equal to/above the one specified in "ReportToGroup" is online
				bool notificationSent = false;
				for (int i = 0; i < allPlayers.Length; i++)
				{
					if (m.GetPlayerPermissionLevel(allPlayers[i]) >= ReportToGroup)
					{
						//Notify members of the specified group that a player has been reported
						m.SendMessage(allPlayers[i], string.Format(GetLocalizedString(58), m.GetPlayerName(player), rep_player, givenReason));
						notificationSent = true;
					}
				}
				if (!notificationSent)
				{
					//Nobody online --> notify next member of the specified group when he/she joins
					//These reports will be lost when the server is restarted
					string[] reportedPlayer = new string[3];
					reportedPlayer[0] = rep_player;                 //Name of the reported player
					reportedPlayer[1] = m.GetPlayerName(player);    //Name of the player who reported
					reportedPlayer[2] = givenReason;                //Reason for the report
					reportedPlayers.Add(reportedPlayer);
				}

				System.Console.WriteLine(string.Format("INFO:  {0} reported {1} (Reason: {2})", m.GetPlayerName(player), rep_player, givenReason));
				m.SendMessage(player, string.Format(GetLocalizedString(59), rep_player, givenReason));
				return true;
			}
			return false;
		}

		void NotifyAboutReports(int player)
		{
			if (m.GetPlayerPermissionLevel(player) >= ReportToGroup)
			{
				//Is member of "ReportToGroup" or higher
				foreach (string[] reportedPlayer in reportedPlayers)
				{
					m.SendMessage(player, string.Format(GetLocalizedString(58), reportedPlayer[1], reportedPlayer[0], reportedPlayer[2]));
				}
				reportedPlayers.Clear();
			}
		}

		bool ChangeSeason(int player, string command, string argument)
		{
			if (command.Equals("season", StringComparison.InvariantCultureIgnoreCase))
			{
				if (!m.PlayerHasPrivilege(player, "season"))
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(60));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to change the season (no permission)", m.GetPlayerName(player)));
					return true;
				}
				int seasonID = -1;
				try
				{
					seasonID = Convert.ToInt32(argument);
				}
				catch (FormatException)
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(1));
					return true;
				}
				catch (OverflowException)
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(2));
					return true;
				}

				//Check if season ID exists
				if ((seasonID < 0) || (seasonID > 3))
				{
					m.SendMessage(player, m.colorError() + string.Format(GetLocalizedString(61), seasonID.ToString()));
					return true;
				}

				//The code used to change the season is entirely taken from Default.cs

				SoundSet solidSounds;
				SoundSet snowSounds;
				SoundSet noSound;
				solidSounds = new SoundSet()
				{
					Walk = new string[] { "walk1", "walk2", "walk3", "walk4" },
					Break = new string[] { "destruct" },
					Build = new string[] { "build" },
					Clone = new string[] { "clone" },
				};
				snowSounds = new SoundSet()
				{
					Walk = new string[] { "walksnow1", "walksnow2", "walksnow3", "walksnow4" },
					Break = new string[] { "destruct" },
					Build = new string[] { "build" },
					Clone = new string[] { "clone" },
				};
				noSound = new SoundSet();

				// spring
				if (seasonID == 0)
				{
					m.SetBlockType(2, "Grass", new BlockType()
					               {
					               	TextureIdTop = "SpringGrass",
					               	TextureIdBack = "SpringGrassSide",
					               	TextureIdFront = "SpringGrassSide",
					               	TextureIdLeft = "SpringGrassSide",
					               	TextureIdRight = "SpringGrassSide",
					               	TextureIdForInventory = "SpringGrassSide",
					               	TextureIdBottom = "Dirt",
					               	DrawType = DrawType.Solid,
					               	WalkableType = WalkableType.Solid,
					               	Sounds = snowSounds,
					               });
					m.SetBlockType(18, "Leaves", new BlockType()
					               {
					               	AllTextures = "Leaves",
					               	DrawType = DrawType.Transparent,
					               	WalkableType = WalkableType.Solid,
					               	Sounds = solidSounds,
					               });
					m.SetBlockType(106, "Apples", new BlockType()
					               {
					               	AllTextures = "Apples",
					               	DrawType = DrawType.Transparent,
					               	WalkableType = WalkableType.Solid,
					               	Sounds = solidSounds,
					               });
				}
				// summer
				if (seasonID == 1)
				{
					m.SetBlockType(2, "Grass", new BlockType()
					               {
					               	TextureIdTop = "Grass",
					               	TextureIdBack = "GrassSide",
					               	TextureIdFront = "GrassSide",
					               	TextureIdLeft = "GrassSide",
					               	TextureIdRight = "GrassSide",
					               	TextureIdForInventory = "GrassSide",
					               	TextureIdBottom = "Dirt",
					               	DrawType = DrawType.Solid,
					               	WalkableType = WalkableType.Solid,
					               	Sounds = solidSounds,
					               });
					m.SetBlockType(18, "Leaves", new BlockType()
					               {
					               	AllTextures = "Leaves",
					               	DrawType = DrawType.Transparent,
					               	WalkableType = WalkableType.Solid,
					               	Sounds = solidSounds,
					               });
					m.SetBlockType(106, "Apples", new BlockType()
					               {
					               	AllTextures = "Apples",
					               	DrawType = DrawType.Transparent,
					               	WalkableType = WalkableType.Solid,
					               	Sounds = solidSounds,
					               });
					m.SetBlockType(8, "Water", new BlockType()
					               {
					               	AllTextures = "Water",
					               	DrawType = DrawType.Fluid,
					               	WalkableType = WalkableType.Fluid,
					               	Sounds = noSound,
					               });
				}
				// autumn
				if (seasonID == 2)
				{
					m.SetBlockType(2, "Grass", new BlockType()
					               {
					               	TextureIdTop = "AutumnGrass",
					               	TextureIdBack = "AutumnGrassSide",
					               	TextureIdFront = "AutumnGrassSide",
					               	TextureIdLeft = "AutumnGrassSide",
					               	TextureIdRight = "AutumnGrassSide",
					               	TextureIdForInventory = "AutumnGrassSide",
					               	TextureIdBottom = "Dirt",
					               	DrawType = DrawType.Solid,
					               	WalkableType = WalkableType.Solid,
					               	Sounds = snowSounds,
					               });
					m.SetBlockType(18, "Leaves", new BlockType()
					               {
					               	AllTextures = "AutumnLeaves",
					               	DrawType = DrawType.Transparent,
					               	WalkableType = WalkableType.Solid,
					               	Sounds = solidSounds,
					               });
					m.SetBlockType(106, "Apples", new BlockType()
					               {
					               	AllTextures = "AutumnApples",
					               	DrawType = DrawType.Transparent,
					               	WalkableType = WalkableType.Solid,
					               	Sounds = solidSounds,
					               });
				}
				// winter
				if (seasonID == 3)
				{
					m.SetBlockType(2, "Grass", new BlockType()
					               {
					               	TextureIdTop = "WinterGrass",
					               	TextureIdBack = "WinterGrassSide",
					               	TextureIdFront = "WinterGrassSide",
					               	TextureIdLeft = "WinterGrassSide",
					               	TextureIdRight = "WinterGrassSide",
					               	TextureIdForInventory = "WinterGrassSide",
					               	TextureIdBottom = "Dirt",
					               	DrawType = DrawType.Solid,
					               	WalkableType = WalkableType.Solid,
					               	Sounds = snowSounds,
					               });
					m.SetBlockType(18, "Leaves", new BlockType()
					               {
					               	AllTextures = "WinterLeaves",
					               	DrawType = DrawType.Transparent,
					               	WalkableType = WalkableType.Solid,
					               	Sounds = solidSounds,
					               });
					m.SetBlockType(106, "Apples", new BlockType()
					               {
					               	AllTextures = "WinterApples",
					               	DrawType = DrawType.Transparent,
					               	WalkableType = WalkableType.Solid,
					               	Sounds = solidSounds,
					               });
					m.SetBlockType(8, "Water", new BlockType()
					               {
					               	AllTextures = "Ice",
					               	DrawType = DrawType.Solid,
					               	WalkableType = WalkableType.Solid,
					               	Sounds = snowSounds,
					               	IsSlipperyWalk = true,
					               });
				}
				m.UpdateBlockTypes();
				System.Console.WriteLine(string.Format("INFO:  {0} changed the season.", m.GetPlayerName(player)));
				return true;
			}
			return false;
		}

		bool SendAFK(int player, string command, string argument)
		{
			if (command.Equals("afk", StringComparison.InvariantCultureIgnoreCase))
			{
				if (!m.PlayerHasPrivilege(player, "afk"))
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(64));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to send an AFK message (no permission)", m.GetPlayerName(player)));
					return true;
				}
				if (string.IsNullOrEmpty(argument))
				{
					//No arguments given
					m.SendMessage(player, m.colorError() + GetLocalizedString(17));
					return true;
				}

				string[] args;
				int time = -1;
				string givenReason = "";
				try
				{
					args = argument.Split(' ');
					time = Convert.ToInt32(args[0]);
					for (int i = 1; i < args.Length; i++)
					{
						givenReason = givenReason + " " + args[i];
					}
				}
				catch (FormatException)
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(1));
					return true;
				}
				catch (OverflowException)
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(2));
					return true;
				}
				if (string.IsNullOrEmpty(givenReason))
				{
					//No AFK reason specified
					m.SendMessage(player, m.colorError() + GetLocalizedString(17));
					return true;
				}

				//Notify all players
				m.SendMessageToAll(string.Format(GetLocalizedString(65), m.GetPlayerName(player), time.ToString(), givenReason));
				return true;
			}
			return false;
		}

		bool SendBTK(int player, string command, string argument)
		{
			if (command.Equals("btk", StringComparison.InvariantCultureIgnoreCase))
			{
				if (!m.PlayerHasPrivilege(player, "afk"))
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(64));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to send a BTK message (no permission)", m.GetPlayerName(player)));
					return true;
				}
				//Notify all players
				m.SendMessageToAll(string.Format(GetLocalizedString(67), m.GetPlayerName(player)));
				return true;
			}
			return false;
		}

		void Uptime_Tick()
		{
			UptimeSeconds++;
			if (UptimeSeconds >= 60)
			{
				UptimeSeconds -= 60;
				UptimeMinutes++;
			}
			if (UptimeMinutes >= 60)
			{
				UptimeMinutes -= 60;
				UptimeHours++;
			}
			if (UptimeHours >= 12)
			{
				UptimeHours -= 12;
				UptimeDays++;
			}
		}

		bool DisplayUptime(int player, string command, string argument)
		{
			if (command.Equals("uptime", StringComparison.InvariantCultureIgnoreCase))
			{
				m.SendMessage(player, "&7Server Uptime:");
				m.SendMessage(player, string.Format(GetLocalizedString(66), UptimeDays.ToString(), UptimeHours.ToString(), UptimeMinutes.ToString(), UptimeSeconds.ToString()));
				return true;
			}
			return false;
		}
		
		bool SendMe(int player, string command, string argument)
		{
			if (command.Equals("me", StringComparison.InvariantCultureIgnoreCase))
			{
				if (!m.PlayerHasPrivilege(player, "me"))
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(68));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to use /me (no permission)", m.GetPlayerName(player)));
					return true;
				}
				m.SendMessageToAll(string.Format("&7{0} {1}", m.GetPlayerName(player), argument));
				return true;
			}
			return false;
		}
		
		bool SetSpectate(int player, string command, string argument)
		{
			if (command.Equals("vanish", StringComparison.InvariantCultureIgnoreCase))
			{
				if (!m.PlayerHasPrivilege(player, "vanish"))
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(69));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to use /vanish (no permission)", m.GetPlayerName(player)));
					return true;
				}
				m.SetPlayerSpectator(player, true);
				m.SendMessageToAll(string.Format(GetLocalizedString(70), m.GetPlayerName(player)));
				return true;
			}
			if (command.Equals("visible", StringComparison.InvariantCultureIgnoreCase))
			{
				if (!m.PlayerHasPrivilege(player, "vanish"))
				{
					m.SendMessage(player, m.colorError() + GetLocalizedString(69));
					System.Console.WriteLine(string.Format("INFO:  {0} tried to use /visible (no permission)", m.GetPlayerName(player)));
					return true;
				}
				m.SetPlayerSpectator(player, false);
				m.SendMessageToAll(string.Format(GetLocalizedString(71), m.GetPlayerName(player)));
				return true;
			}
			return false;
		}
	}
}

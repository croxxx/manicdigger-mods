Switchable Lights Mod by croxxx
�������������������������������


   ------------------------------------------------------------------------------------------
  | This Mod adds a new light block to creative Inventory that can be toggled on and off.    |
  | --> To be able to toggle lights the player must have the privilege "toggle".             |
  |                                                                                          |
  | Additionally there is a command "/toggle_all [0/1]" that switches all lights on the map. |
  | --> To be able to use this command the player must have the "toggle_all" privilege.      |
   ------------------------------------------------------------------------------------------




Installation:
�������������
1. Copy "SwitchableLight.cs" into the folder "Mods" of your Manic Digger installation directory. ("Mods\Fortress" since MD version 2012-09-26)
2. Copy the 2 texture files "light_on.png" and "light_off.png" into the subfolder "data\public\blocks" in your Manic Digger installation directory.
3. Open "ServerConfig.txt" in "UserData\Configuration" and add the privileges "toggle" and "toggle_all" to the Admin group.
4. Start Manic Digger and enjoy switchable light blocks.



Compatibility:
��������������
- uses Block IDs 254 and 255
- no conflicts with other mods (so far)



Additional Note:
����������������
All textures for this mod were created entirely by me. No templates or other pictures were used.
The original GIMP .xcf files made by me are included in the subfolder "Original GIMP texture files".
They have a resolution of 512 x 512 pixels.
You may use them for whatever you like. Just don't claim them your own.
﻿/*
 * Teleport Blocks Mod - Version 1.0
 * Author: croxxx
 * 
 * This mod adds "Teleport Blocks" to your server.
 * Following privileges are added:
 * -use_tpblock:            Allows the user/group to use the teleport functions of teleport blocks
 * -set_tptarget:           Allows the user/group to set the target positions for teleport blocks
 * -get_tpblocks:           Allows the user/group to get all teleport blocks available with the command "/get_tpblocks"
 * -delete_tpblocks:        Allows the user/group to delete single Teleport Blocks
 * -delete_all_tpblocks:    Allows the user/group to delete all Teleport Blocks at once (useful if BlockIDs shall be changed)
 * 
 * Usage:
 * -Place any Teleport Block you want anywhere in the world. You will be reminded if the placed block has no target set.
 * -Set a target for the placed Teleport Block using "/set_tptarget". Syntax: "/set_tptarget [Teleport_Block_ID] [Target_X] [Target_Y] [Target_Z]"
 * -If you destroy a Teleport Block its target position will be reset, too.
 * -If you want to move a Teleport Block and keep its target position just place the same Teleport Block anywhere again. The old block will be removed automatically.
 */

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ManicDigger.Mods
{
    public class TeleportBlocks : IMod
    {
        public void PreStart(ModManager m)
        {
            m.RequireMod("Default");
        }
        public void Start(ModManager m)
        {
            this.m = m;
            
			m.RegisterOnBlockUse(Teleport);
            m.RegisterOnBlockBuild(AddBlock);
            m.RegisterOnBlockDelete(DeleteBlock);
            m.RegisterPrivilege("use_tpblock");
            m.RegisterPrivilege("set_tptarget");
            m.RegisterPrivilege("get_tpblocks");
            m.RegisterPrivilege("delete_tpblocks");
            m.RegisterPrivilege("delete_all_tpblocks");
            m.RegisterCommandHelp("use_tpblock", "Allows you to use teleport blocks");
            m.RegisterCommandHelp("set_tptarget", "/set_tptarget [blockID] [X] [Y] [Z]");
            m.RegisterCommandHelp("get_tpblocks", "Gives you all available teleport blocks");
            m.RegisterCommandHelp("delete_all_tpblocks", "Deletes ALL teleport blocks and their targets");
            m.RegisterOnCommand(SetTarget);
            m.RegisterOnCommand(GiveBlocks);
            m.RegisterOnCommand(DeleteAll);
			m.RegisterOnLoad(LoadTargetPositions);
            m.RegisterOnSave(SaveTargetPositions);

            SoundSet solidSounds = new SoundSet()
            {
                Walk = new string[] { "walk1", "walk2", "walk3", "walk4" },
                Break = new string[] { "destruct" },
                Build = new string[] { "build" },
                Clone = new string[] { "clone" },
            };

            for (int i = 0; i < number_of_teleport_blocks; i++)
            {
                m.SetString("en", "Teleport_Block_" + i.ToString(), "Teleport Block");

                m.SetBlockType(blockID_start + i, "Teleport_Block_" + i.ToString(), new BlockType()
                {
                    AllTextures = "Teleport_" + i.ToString(),
                    DrawType = DrawType.Transparent,
                    WalkableType = WalkableType.Solid,
                    Sounds = solidSounds,
                    IsUsable = true,
                });
            }
        }

        ModManager m;
        Vector3i[] positions = new Vector3i[number_of_teleport_blocks]; //Stores positions of placed teleport blocks
        Vector3i[] targets = new Vector3i[number_of_teleport_blocks];   //Stores target positions of the teleport blocks
        bool[] isPlaced = new bool[number_of_teleport_blocks];          //Indicates if a teleport block is already placed

        const int number_of_teleport_blocks = 10;       //The total number of teleport blocks that shall be available
        const int blockID_start = 245;                  //The block ID of the first teleport block
		
		//Adapted from Tnt.cs
		struct Vector3i
        {
            public Vector3i(int x, int y, int z)
            {
                this.x = x;
                this.y = y;
                this.z = z;
            }
            public int x;
            public int y;
            public int z;
        }

        bool IsTargetValid(Vector3i vector)
        {
            if ((vector.x == -1) || (vector.y == -1) || (vector.z == -1))
            {
                return false;
            }
            return true;
        }

        bool IsTeleportBlock(int BlockID)
        {
            if ((BlockID >= blockID_start) && (BlockID < (blockID_start + number_of_teleport_blocks)))
            {
                return true;
            }
            return false;
        }
        
        //Load and Save inspired by BuildLog.cs
        void LoadTargetPositions()
        {
            try
            {
                byte[] b = m.GetGlobalData("TeleportBlocks");
                if (b != null)
                {
                    MemoryStream ms = new MemoryStream(b);
                    BinaryReader br = new BinaryReader(ms);
                    for (int i = 0; i < number_of_teleport_blocks; i++)
                    {
                        int loadedPos_x = br.ReadInt16();
                        int loadedPos_y = br.ReadInt16();
                        int loadedPos_z = br.ReadInt16();

                        int loadedTar_x = br.ReadInt16();
                        int loadedTar_y = br.ReadInt16();
                        int loadedTar_z = br.ReadInt16();

                        bool loadedIsSet = br.ReadBoolean();

                        positions[i] = new Vector3i(loadedPos_x, loadedPos_y, loadedPos_z);
                        targets[i] = new Vector3i(loadedTar_x, loadedTar_y, loadedTar_z);
                        isPlaced[i] = loadedIsSet;
                    }
                }
            }
            catch
            {
                //if data corrupted
                SaveTargetPositions();
            }
        }

        void SaveTargetPositions()
        {
            MemoryStream ms = new MemoryStream();
            BinaryWriter bw = new BinaryWriter(ms);
            for (int i = 0; i < number_of_teleport_blocks; i++)
            {
                Vector3i dataPos = positions[i];
                Vector3i dataTar = targets[i];
                bool dataIsSet = isPlaced[i];

                bw.Write((short)dataPos.x);
                bw.Write((short)dataPos.y);
                bw.Write((short)dataPos.z);

                bw.Write((short)dataTar.x);
                bw.Write((short)dataTar.y);
                bw.Write((short)dataTar.z);

                bw.Write((bool)dataIsSet);
            }
            m.SetGlobalData("TeleportBlocks", ms.ToArray());
        }

        void Teleport(int player, int x, int y, int z)
        {
            int ID = m.GetBlockId(m.GetBlockNameAt(x, y, z));
            if (IsTeleportBlock(ID))
            {
                if (!m.PlayerHasPrivilege(player, "use_tpblock"))
                {
                    m.SendMessage(player, m.colorError() + "You are not allowed to use teleport blocks.");
                    return;
                }

                Vector3i targetPosition = targets[ID - blockID_start];
                if (IsTargetValid(targetPosition))
                {
                    m.SetPlayerPosition(player, targetPosition.x, targetPosition.y, targetPosition.z);
                    return;
                }
                else
                {
                    m.SendMessage(player, m.colorError() + "This block has no target set.");
                    return;
                }
            }
		}

		void AddBlock(int player, int x, int y, int z)
		{
            int ID = m.GetBlockId(m.GetBlockNameAt(x, y, z));
            if (IsTeleportBlock(ID))
			{
                int ID2 = ID - blockID_start;
                if (isPlaced[ID2])  //Check if Block with same ID is already set
                {
                    Vector3i oldPos = positions[ID2];               //Get position of old block
                    m.SetBlock(oldPos.x, oldPos.y, oldPos.z, 0);    //Set block at old position to "Empty"
                    positions[ID2] = new Vector3i(x, y, z);         //Save position of new block
                    m.SendMessage(player, m.colorError() + "INFO: Teleport Block position updated. Old block deleted.");
                }
                else
                {
                    positions[ID2] = new Vector3i(x, y, z);     //Save position of new block
                    isPlaced[ID2] = true;                       //Set BlockID as used
                }
                if (!IsTargetValid(targets[ID2]))
                {
                    m.SendMessage(player, m.colorError() + "INFO: Remember to set a target for this teleport block.");  //Notify user if there is no target set
                }
			}
		}
		
		void DeleteBlock(int player, int x, int y, int z, int BlockID)
		{
            if (IsTeleportBlock(BlockID))
            {
                if (!m.PlayerHasPrivilege(player, "delete_tpblocks"))
                {
                    m.SetBlock(x, y, z, BlockID);
                    m.SendMessage(player, m.colorError() + "You are not allowed to delete teleport blocks.");
                    return;
                }
                int ID = BlockID - blockID_start;
                positions[ID] = new Vector3i(-1, -1, -1);
                targets[ID] = new Vector3i(-1, -1, -1);
                isPlaced[ID] = false;
                m.SendMessage(player, m.colorError() + "INFO: The block and its target position have been deleted.");
            }
		}

        bool SetTarget(int player, string command, string argument)
        {
            if (command.Equals("set_tptarget", StringComparison.InvariantCultureIgnoreCase))
            {
                if (!m.PlayerHasPrivilege(player, "set_tptarget"))
                {
                    m.SendMessage(player, m.colorError() + "You are not allowed to set teleport block targets.");
                    return true;
                }
                int teleportBlockID;
                int targetX;
                int targetY;
                int targetZ;
                try
                {
                    string[] args = argument.Split(' ');
                    teleportBlockID = int.Parse(args[0]);
                    targetX = int.Parse(args[1]);
                    targetY = int.Parse(args[2]);
                    targetZ = int.Parse(args[3]);
                }
                catch
                {
                    m.SendMessage(player, m.colorError() + "Invalid arguments. Type /help to see command's usage.");
                    return true;
                }

                if ((teleportBlockID < number_of_teleport_blocks) && (teleportBlockID >= 0))
                {
                    if (m.IsValidPos(targetX, targetY, targetZ))
                    {
                        targets[teleportBlockID] = new Vector3i(targetX, targetY, targetZ);
                        m.SendMessage(player, "Succesfully set target coordinates:");
                        m.SendMessage(player, string.Format("Teleport Block {0} now teleports people to {1}, {2}, {3}", teleportBlockID, targetX, targetY, targetZ));
                        m.LogServerEvent(string.Format("{0} set Teleport Block {1} target coordinates to {2}, {3}, {4}", m.GetPlayerName(player), teleportBlockID, targetX, targetY, targetZ));
                        return true;
                    }
                    else
                    {
                        m.SendMessage(player, m.colorError() + "The coordinates you entered are not valid.");
                        return true;
                    }
                }
                else
                {
                    m.SendMessage(player, m.colorError() + "The teleport block ID you entered does not exist.");
                    return true;
                }
            }
            return false;
        }

        bool GiveBlocks(int player, string command, string argument)
		{
            if (command.Equals("get_tpblocks", StringComparison.InvariantCultureIgnoreCase))
            {
                if (!m.PlayerHasPrivilege(player, "get_tpblocks"))
				{
					m.SendMessage(player, m.colorError() + "You are not allowed to give yourself teleport blocks.");
					return true;
				}
                for (int i = blockID_start; i < (blockID_start + number_of_teleport_blocks); i++)
                {
                    m.GrabBlock(player, i);
                }
                m.NotifyInventory(player);
                return true;
			}
			return false;
		}

        bool DeleteAll(int player, string command, string argument)
        {
            if (command.Equals("delete_all_tpblocks", StringComparison.InvariantCultureIgnoreCase))
            {
                if (!m.PlayerHasPrivilege(player, "delete_all_tpblocks"))
                {
                    m.SendMessage(player, m.colorError() + "You are not allowed to delete ALL teleport blocks.");
                    return true;
                }
                for (int i = 0; i < number_of_teleport_blocks; i++)
                {
                    Vector3i emptyVector = new Vector3i(-1, -1, -1);
                    targets[i] = emptyVector;
                    Vector3i tempPos = positions[i];
                    m.SetBlock(tempPos.x, tempPos.y, tempPos.z, 0); //Set Block to "Empty"
                    positions[i] = emptyVector;
                    isPlaced[i] = false;
                }
                m.SendMessage(player, "ALL teleport blocks and their targets have been deleted.");
                return true;
            }
            return false;
        }
    }
}

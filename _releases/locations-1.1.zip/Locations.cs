﻿/*
 * Locations Mod - Version 1.1
 * Author: croxxx
 * 
 * This mod adds locations to your server.
 * Every time a player enters one of the locations a message is displayed
 * Example: You just arrived at <location name>
 * 
 * Following command is added:
 * /location
 * Command options are:
 *    add [startx] [starty] [startz] [endx] [endy] [endz] [name]
 *    delete [name]
 *    list
 *    clear
 *    help
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ManicDigger.Mods
{
    public class Locations : IMod
    {
        //Enter the desired language code here. Currently supported are EN and DE.
        string languageCode = "EN";
        //Maximum number of players on your server
        const int maxPlayerCount = 16;
        
        public void PreStart(ModManager m)
        {
            m.RequireMod("Default");
        }

        public void Start(ModManager m)
        {
            this.m = m;

            m.RegisterPrivilege("manage_locations");
            m.RegisterCommandHelp("manage_locations", "Allows you to add/delete locations");
            m.RegisterTimer(CheckPlayerPosition, (double)1);
            m.RegisterOnCommand(ManageAreas);
            m.RegisterOnLoad(LoadLocations);
            m.RegisterOnSave(SaveLocations);
            for (int i = 0; i < maxPlayerCount; i++)
            {
                PlayerLastSeenIn[i] = "";
            }
        }
        ModManager m;

        struct Vector3i
        {
            public Vector3i(int x, int y, int z)
            {
                this.x = x;
                this.y = y;
                this.z = z;
            }
            public int x;
            public int y;
            public int z;
        }
        struct Location
        {
            public Location(Vector3i startpos, Vector3i endpos)
            {
                if (startpos.x < endpos.x)
                {
                    start.x = startpos.x;
                    end.x = endpos.x;
                }
                else
                {
                    start.x = endpos.x;
                    end.x = startpos.x;
                }
                if (startpos.y < endpos.y)
                {
                    start.y = startpos.y;
                    end.y = endpos.y;
                }
                else
                {
                    start.y = endpos.y;
                    end.y = startpos.y;
                }
                if (startpos.z < endpos.z)
                {
                    start.z = startpos.z;
                    end.z = endpos.z;
                }
                else
                {
                    start.z = endpos.z;
                    end.z = startpos.z;
                }
                size.x = (end.x - start.x) + 1;
                size.y = (end.y - start.y) + 1;
                size.z = (end.z - start.z) + 1;
                name = "&4unspecified";
            }
            public Vector3i start;
            public Vector3i end;
            public readonly Vector3i size;
            public string name;
        }

        string GetLocalizedString(string value)
        {
            switch (languageCode)
            {
                #region German translation
                case "DE":
                    switch (value)
                    {
                        case "location_change":
                            return "Du hast gerade&3{0} &ferreicht.";
                        case "invalid_args":
                            return "Üngültige Argumente. Schau mal in &7/location help.";
                        case "privilege_missing":
                            return "Du darfst die Bereiche nicht verwalten.";
                        case "add_success":
                            return "Bereich&7{0} &erfolgreich erstellt.";
                        case "add_start":
                            return "Start-Koordinaten: &7{0}, {1}, {2}";
                        case "add_end":
                            return "End-Koordinaten: &7{0}, {1}, {2}";
                        case "del_success":
                            return "Bereich&7{0} &fgelöscht.";
                        case "del_all_success":
                            return "Alle Bereiche gelöscht.";
                        case "list_title":
                            return "Liste aller Bereiche:";
                        case "error_exist":
                            return "Bereich{0} existiert nicht.";
                        case "error_nolocations":
                            return "Es sind keine Bereiche vorhanden.";
                        case "help_1":
                            return "Folgende Kommandos stehen zur Verfügung:";
                        case "help_2":
                            return "/location add [sx] [sy] [sz] [ex] [ey] [ez] [name]";
                        case "help_3":
                            return "/location delete [name]";
                        case "help_4":
                            return "/location list";
                        case "help_5":
                            return "/location clear";
                        
                        default:
                            return string.Format("&4FEHLER: &fString '{0}' existiert nicht.", value);
                    }
                #endregion

                #region English translation
                case "EN":
                    switch (value)
                    {
                        case "location_change":
                            return "You just arrived at&3{0}.";
                        case "invalid_args":
                            return "Invalid arguments. Try &7/location help.";
                        case "privilege_missing":
                            return "You are not allowed to manage locations.";
                        case "add_success":
                            return "Location&7{0} &fadded successfully.";
                        case "add_start":
                            return "Start coordinates: &7{0}, {1}, {2}";
                        case "add_end":
                            return "End coordinates: &7{0}, {1}, {2}";
                        case "del_success":
                            return "Location&7{0} &fdeleted.";
                        case "del_all_success":
                            return "All locations deleted.";
                        case "list_title":
                            return "List of Locations:";
                        case "error_exist":
                            return "Location{0} does not exist.";
                        case "error_nolocations":
                            return "There are no locations stored.";
                        case "help_1":
                            return "Following commands are available:";
                        case "help_2":
                            return "/location add [sx] [sy] [sz] [ex] [ey] [ez] [name]";
                        case "help_3":
                            return "/location delete [name]";
                        case "help_4":
                            return "/location list";
                        case "help_5":
                            return "/location clear";
                        
                        default:
                            return string.Format("&4ERROR: &fString '{0}' does not exist.", value);
                    }
                #endregion

                default:
                    return string.Format("&4ERROR: &fThe language code {0} is not in the list.", languageCode);
            }
        }
        
        Vector3i GetPlayerPosition(int PlayerID)
        {
            return new Vector3i((int)m.GetPlayerPositionX(PlayerID), (int)m.GetPlayerPositionY(PlayerID), (int)m.GetPlayerPositionZ(PlayerID));
        }

        void LoadLocations()
        {
            try
            {
                byte[] b = m.GetGlobalData("Locations");
                if (b != null)
                {
                    MemoryStream ms = new MemoryStream(b);
                    BinaryReader br = new BinaryReader(ms);
                    int count = br.ReadInt32();
                    for (int i = 0; i < count; i++)
                    {
                        int loaded_startx = br.ReadInt16(); //Start x
                        int loaded_starty = br.ReadInt16(); //Start y
                        int loaded_startz = br.ReadInt16(); //Start z
                        int loaded_endx = br.ReadInt16(); //End x
                        int loaded_endy = br.ReadInt16(); //End y
                        int loaded_endz = br.ReadInt16(); //End z
                        Vector3i loc_start = new Vector3i(loaded_startx, loaded_starty, loaded_startz);
                        Vector3i loc_end = new Vector3i(loaded_endx, loaded_endy, loaded_endz);
                        Location loadedLocation = new Location(loc_start, loc_end);
                        loadedLocation.name = br.ReadString(); //Location Name
                        locationList.Add(loadedLocation);
                    }
                }
            }
            catch
            {
                //data corrupted
                SaveLocations();
            }
        }

        void SaveLocations()
        {
            MemoryStream ms = new MemoryStream();
            BinaryWriter bw = new BinaryWriter(ms);
            bw.Write((int)locationList.Count);
            for (int i = 0; i < locationList.Count; i++)
            {
                Vector3i loc_start = locationList[i].start;
                Vector3i loc_end = locationList[i].end;
                bw.Write((short)loc_start.x); //Start x
                bw.Write((short)loc_start.y); //Start y
                bw.Write((short)loc_start.z); //Start z
                bw.Write((short)loc_end.x); //End x
                bw.Write((short)loc_end.y); //End y
                bw.Write((short)loc_end.z); //End z
                bw.Write(locationList[i].name); //Location Name
            }
            m.SetGlobalData("Locations", ms.ToArray());
        }
        
        List<Location> locationList = new List<Location>();
        string[] PlayerLastSeenIn = new string[maxPlayerCount];

        void CheckPlayerPosition()
        {
            int[] players = m.AllPlayers();
            foreach (int player in players)
            {
                Vector3i position = GetPlayerPosition(player);
                string lastSeen = PlayerLastSeenIn[player];
                bool PlayerInAnyArea = false;
                foreach (Location location in locationList)
                {
                    if (IsInArea(location, position))
                    {
                        //Player is in a defined area
                        PlayerInAnyArea = true;
                        if (!lastSeen.Equals(location.name, StringComparison.InvariantCultureIgnoreCase))
                        {
                            //Player entered different area
                            m.SendMessage(player, string.Format(GetLocalizedString("location_change"), location.name));
                            PlayerLastSeenIn[player] = location.name;
                            return;
                        }
                    }
                }
                if (!PlayerInAnyArea)
                    PlayerLastSeenIn[player] = "";
            }
        }
        
        void AddArea(Vector3i AreaStart, Vector3i AreaEnd, string AreaName)
        {
            Location newLocation = new Location(AreaStart, AreaEnd);
            newLocation.name = AreaName;
            locationList.Add(newLocation);
        }

        bool DeleteArea(string AreaName)
        {
            for (int i = 0; i < locationList.Count; i++)
            {
                if (AreaName.Equals(locationList[i].name, StringComparison.InvariantCultureIgnoreCase))
                {
                    locationList.RemoveAt(i);
                    return true;
                }
            }
            return false;
        }

        bool IsInArea(Location loc, Vector3i position)
        {
            Vector3i area_start = loc.start;
            Vector3i area_end = loc.end;
            if ((area_start.x <= position.x) && (position.x <= area_end.x))
            {
                if ((area_start.y <= position.y) && (position.y <= area_end.y))
                {
                    if ((area_start.z <= position.z) && (position.z <= area_end.z))
                    {
                        return true;
                    }
                    return false;
                }
                return false;
            }
            return false;
        }
        
        bool ManageAreas(int player, string command, string argument)
        {
            if (command.Equals("location", StringComparison.InvariantCultureIgnoreCase))
            {
                string[] args;
                string option = "";
                try
                {
                    args = argument.Split(' ');
                    option = args[0];
                }
                catch
                {
                    m.SendMessage(player, m.colorError() + GetLocalizedString("invalid_args"));
                    return true;
                }

                if (option.Equals("add", StringComparison.InvariantCultureIgnoreCase))
                {
                    if (!m.PlayerHasPrivilege(player, "manage_locations"))
                    {
                        m.SendMessage(player, m.colorError() + GetLocalizedString("privilege_missing"));
                        return true;
                    }
                    int startx, starty, startz, endx, endy, endz = -1;
                    string newName = "";
                    try
                    {
                        startx = Convert.ToInt32(args[1]);
                        starty = Convert.ToInt32(args[2]);
                        startz = Convert.ToInt32(args[3]);
                        endx = Convert.ToInt32(args[4]);
                        endy = Convert.ToInt32(args[5]);
                        endz = Convert.ToInt32(args[6]);
                        for (int i = 7; i < args.Length; i++)
                        {
                            newName = newName + " " + args[i];
                        }
                    }
                    catch
                    {
                        m.SendMessage(player, m.colorError() + GetLocalizedString("invalid_args"));
                        return true;
                    }
                    Vector3i start = new Vector3i(startx, starty, startz);
                    Vector3i end = new Vector3i(endx, endy, endz);
                    AddArea(start, end, newName);
                    m.SendMessage(player, string.Format(GetLocalizedString("add_success"), newName));
                    m.SendMessage(player, string.Format(GetLocalizedString("add_start"), startx.ToString(), starty.ToString(), startz.ToString()));
                    m.SendMessage(player, string.Format(GetLocalizedString("add_end"), endx.ToString(), endy.ToString(), endz.ToString()));
                    return true;
                }
                if (option.Equals("delete", StringComparison.InvariantCultureIgnoreCase))
                {
                    if (!m.PlayerHasPrivilege(player, "manage_locations"))
                    {
                        m.SendMessage(player, m.colorError() + GetLocalizedString("privilege_missing"));
                        return true;
                    }
                    string delName = "";
                    try
                    {
                        for (int i = 1; i < args.Length; i++)
                        {
                            delName = delName + " " + args[i];
                        }
                    }
                    catch
                    {
                        m.SendMessage(player, m.colorError() + GetLocalizedString("invalid_args"));
                        return true;
                    }

                    if (DeleteArea(delName))
                    {
                        m.SendMessage(player, string.Format(GetLocalizedString("del_success"), delName));
                        return true;
                    }
                    else
                    {
                        m.SendMessage(player, m.colorError() + string.Format(GetLocalizedString("error_exist"), delName));
                        return true;
                    }
                }
                if (option.Equals("list", StringComparison.InvariantCultureIgnoreCase))
                {
                    if (locationList.Count > 0)
                    {
                        m.SendMessage(player, GetLocalizedString("list_title"));
                        m.SendMessage(player, "----------------------------------------");
                        foreach (Location loc in locationList)
                        {
                            m.SendMessage(player, string.Format("-{0}", loc.name));
                        }
                        return true;
                    }
                    m.SendMessage(player, m.colorError() + GetLocalizedString("error_nolocations"));
                    return true;
                }
                if (option.Equals("clear", StringComparison.InvariantCultureIgnoreCase))
                {
                    if (!m.PlayerHasPrivilege(player, "manage_locations"))
                    {
                        m.SendMessage(player, m.colorError() + GetLocalizedString("privilege_missing"));
                        return true;
                    } 
                    locationList.Clear();
                    m.SendMessage(player, GetLocalizedString("del_all_success"));
                    return true;
                }
                if (option.Equals("help", StringComparison.InvariantCultureIgnoreCase))
                {
                    m.SendMessage(player, GetLocalizedString("help_1"));
                    m.SendMessage(player, GetLocalizedString("help_2"));
                    m.SendMessage(player, GetLocalizedString("help_3"));
                    m.SendMessage(player, GetLocalizedString("help_4"));
                    m.SendMessage(player, GetLocalizedString("help_5"));
                    return true;
                }
                m.SendMessage(player, m.colorError() + GetLocalizedString("invalid_args"));
                return true;
            }
            return false;
        }
    }
}
